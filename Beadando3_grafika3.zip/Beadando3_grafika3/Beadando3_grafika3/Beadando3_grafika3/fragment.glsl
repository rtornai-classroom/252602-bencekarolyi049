// ===============================
// fragment_shader.glsl
// ===============================

#version 120

//
// Vertex shaderből érkező adatok
//
varying vec3 FragPos;
varying vec3 Normal;

void main()
{
    //
    // Fényforrás pozíció
    //
    vec3 lightPos = vec3(10.0, 10.0, 0.0);

    //
    // Fény iránya
    //
    vec3 lightDir =
        normalize(lightPos - FragPos);

    //
    // Normálvektor normalizálása
    //
    vec3 norm = normalize(Normal);

    //
    // Diffúz megvilágítás
    //
    float diff =
        max(dot(norm, lightDir), 0.0);

    //
    // Kocka színe (fehér)
    //
    vec3 objectColor =
        vec3(1.0, 1.0, 1.0);

    //
    // Fény színe
    //
    vec3 lightColor =
        vec3(1.0, 0.6, 0.2);

    //
    // Ambient komponens
    //
    vec3 ambient =
        0.2 * objectColor;

    //
    // Diffúz komponens
    //
    vec3 diffuse =
        diff * lightColor * objectColor;

    //
    // Végső szín
    //
    vec3 result =
        ambient + diffuse;

    //
    // Pixel szín kiírása
    //
    gl_FragColor =
        vec4(result, 1.0);
}