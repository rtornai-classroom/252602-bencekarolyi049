// ===============================
// vertex_shader.glsl
// ===============================

#version 120

//
// Vertex pozíció
//
varying vec3 FragPos;

//
// Vertex normálvektor
//
varying vec3 Normal;

void main()
{
    //
    // Vertex pozíció világkoordinátában
    //
    FragPos = vec3(gl_ModelViewMatrix * gl_Vertex);

    //
    // Normálvektor transzformálása
    //
    Normal = normalize(gl_NormalMatrix * gl_Normal);

    //
    // Végső pozíció
    //
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}