﻿#include <GL/glut.h>
#include <cmath>

// --- Globális változók a feladat paramétereihez ---
float r = 9.0f;           // Kamera sugara (hengerkoordináták alapja)
float angleCam = 0.0f;    // Kamera szöge (alpha) - Bal/Jobb nyilakkal módosítjuk
float camZ = 0.0f;        // Kamera magassága (h) - Fel/Le nyilakkal módosítjuk
bool lightingEnabled = true; // Fénykapcsoló állapota ('L' billentyű)
float lightAngle = 0.0f;  // A fény aktuális pozíciója a körpályán

// --- Inicializálás ---
void init()
{
    glEnable(GL_DEPTH_TEST); // Z-buffer: Gondoskodik a helyes takarásról (mi van elöl/hátul)

    glEnable(GL_LIGHTING);   // Világítás globális bekapcsolása
    glEnable(GL_LIGHT0);     // A 0-ás számú fényforrás (a Napunk) aktiválása

    glClearColor(0.1f, 0.1f, 0.1f, 1.0f); // Sötétszürke háttérszín
}

// --- Kamera beállítása (Hengerfelületi mozgás) ---
void setCamera()
{
    // Hengerkoordináták konvertálása Descartes-koordinátákba (X, Y)
    float camX = r * cos(angleCam);
    float camY = r * sin(angleCam);

    // gluLookAt(szem pozíciója, nézett pont (origó), UP vektor)
    gluLookAt(
        camX, camY, camZ,   // A kamera a henger palástján mozog
        0.0f, 0.0f, 0.0f,   // Mindig a középpontot nézi
        0.0f, 0.0f, 1.0f    // A Z-tengely az "Észak" (UP vektor)
    );
}

// --- Kockák rajzolása ---
void drawCube(float x, float y, float z)
{
    glPushMatrix(); // Aktuális mátrix mentése
    glTranslatef(x, y, z); // Kocka pozicionálása a térben

    // Kocka anyagának beállítása (fehér visszaverődés)
    GLfloat material[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, material);

    glutSolidCube(1.0); // Egységnyi (1.0) oldalú tömör kocka kirajzolása
    glPopMatrix(); // Mátrix visszaállítása a következő tárgyhoz
}

// --- Fényforrás és a Nap-gömb kezelése ---
void setupLight()
{
    if (!lightingEnabled) // Ha kikapcsoltuk a fényt, ne csináljon semmit
    {
        glDisable(GL_LIGHTING);
        return;
    }

    glEnable(GL_LIGHTING);

    // Fényforrás pozíciója (2*r távolságú körpályán mozog a Z=0 síkban)
    float lightX = (2.0f * r) * cos(lightAngle);
    float lightY = (2.0f * r) * sin(lightAngle);

    GLfloat lightPos[] = { lightX, lightY, 0.0f, 1.0f }; // Pozíció vektor
    GLfloat diffuse[] = { 1.0f, 0.6f, 0.2f, 1.0f };    // Narancssárgás fény színe

    glLightfv(GL_LIGHT0, GL_POSITION, lightPos); // Fény pozíciójának átadása
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);   // Fény színének átadása

    // --- Fényforrást reprezentáló gömb rajzolása ---
    glPushMatrix();
    glDisable(GL_LIGHTING); // A gömböt ne világítsa meg semmi (önmagától "világít")
    glColor3f(1.0f, 0.6f, 0.2f); // Narancssárga szín a gömbnek
    glTranslatef(lightX, lightY, 0.0f); // A gömböt a fényforrás helyére toljuk
    glutSolidSphere(0.5, 30, 30); // Gömb rajzolása (0.5 sugárral)

    if (lightingEnabled)
        glEnable(GL_LIGHTING);
    glPopMatrix();
}

// --- Fő megjelenítési függvény ---
void display()
{
    // Képernyő és Z-buffer törlése
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity(); // Modellnézeti mátrix alaphelyzetbe

    setCamera(); // Kamera elhelyezése
    setupLight(); // Fény beállítása és Nap rajzolása

    // 3 darab kocka kirajzolása (Z-tengely mentén eltolva)
    drawCube(0.0f, 0.0f, 0.0f);   // Középső kocka az origóban
    drawCube(0.0f, 0.0f, 2.0f);   // Felső kocka (közte és az origó közt elférne egy)
    drawCube(0.0f, 0.0f, -2.0f);  // Alsó kocka

    glutSwapBuffers(); // Dupla pufferelés: villogásmentes képcsere
}

// --- Ablak átméretezése és perspektíva ---
void reshape(int w, int h)
{
    glViewport(0, 0, w, h); // A rajzfelület mérete

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // gluPerspective(Látószög: 55 fok, Képarány, Közeli vágósík, Távoli vágósík)
    gluPerspective(55.0, (float)w / (float)h, 1.0, 100.0);

    glMatrixMode(GL_MODELVIEW);
}

// --- Billentyűzet kezelés (L gomb) ---
void keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 'l':
    case 'L':
        lightingEnabled = !lightingEnabled; // Világítás kapcsolgatása
        break;
    case 27: // ESC billentyű kilépéshez
        exit(0);
        break;
    }
    glutPostRedisplay();
}

// --- Speciális gombok kezelése (Nyilak) ---
void specialKeys(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:  angleCam -= 0.05f; break; // Kamera forgatása balra
    case GLUT_KEY_RIGHT: angleCam += 0.05f; break; // Kamera forgatása jobbra
    case GLUT_KEY_UP:    camZ += 0.2f;      break; // Kamera emelése
    case GLUT_KEY_DOWN:  camZ -= 0.2f;      break; // Kamera süllyesztése
    }
    glutPostRedisplay();
}

// --- Időzítő függvény (Animációhoz) ---
void update(int value)
{
    lightAngle += 0.01f; // A fény szögének növelése a keringéshez

    if (lightAngle > 2.0f * 3.14159f)
        lightAngle = 0.0f; // Körbeért a fény

    glutPostRedisplay(); // Kép frissítése
    glutTimerFunc(16, update, 0);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1000, 700);
    glutCreateWindow("Szamitogepes grafika beadando");

    init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutTimerFunc(16, update, 0); // Animáció indítása

    glutMainLoop(); // Eseményhurok indítása
    return 0;
}